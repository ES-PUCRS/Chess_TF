public enum Team{
    White, Black, NONE
}